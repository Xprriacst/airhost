export interface Property {
  id: string;
  name: string;
  address: string;
  accessCodes: {
    wifi: string | { name: string; password: string };
    door: string;
    other?: Record<string, string>;
  };
  houseRules: string[];
  amenities: string[];
  checkInTime: string;
  checkOutTime: string;
  maxGuests: number;
  photos: string[];
  description?: string;
  parkingInfo?: string;
  restaurants?: string[];
  fastFood?: string[];
  emergencyContacts?: string[];
  additionalInfo?: {
    windows?: string;
    tv?: string;
    heating?: string;
    bikes?: string;
  };
}

// ... (le reste du code reste le même)