import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Edit2, Trash2, MessageSquare, Users, Clock, Zap } from 'lucide-react';
import type { Property } from '../../types';

const Properties: React.FC = () => {
  const navigate = useNavigate();
  const [properties] = useState<Property[]>([
    {
      id: '1',
      name: 'Sunset Villa',
      address: '123 Ocean Drive, Miami Beach, FL',
      accessCodes: {
        wifi: 'sunset2024',
        door: '4080#',
      },
      houseRules: ['No smoking', 'No parties', 'Quiet hours 10 PM - 8 AM'],
      amenities: ['Pool', 'Beach access', 'Free parking'],
      checkInTime: '15:00',
      checkOutTime: '11:00',
      maxGuests: 6,
      photos: ['https://images.unsplash.com/photo-1564013799919-ab600027ffc6'],
    },
    {
      id: '2',
      name: 'Studio Blois',
      address: '13 rue des Papegaults, Blois',
      accessCodes: {
        wifi: {
          name: 'FREEBOX-AE4AC6',
          password: 'barbani@%-solvi38-irrogatura-cannetum?&'
        },
        door: '210',
      },
      houseRules: ['Max 4 people', 'No extra visitors', 'Respect noise levels'],
      amenities: ['TV', 'Kitchen', 'Heating'],
      checkInTime: '15:00',
      checkOutTime: '11:00',
      maxGuests: 4,
      photos: ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267'],
      description: 'Bienvenue dans notre charmant studio en plein cœur de Blois, idéal pour découvrir cette ville historique. Ce logement lumineux et confortable convient parfaitement à un séjour en couple ou en solo.',
      parkingInfo: 'Parking gratuit : Parking du Mail (5 minutes à pied). Parking payant : Halle aux Grains (8 minutes à pied, environ 9€/jour).',
      restaurants: [
        'Brute Maison de Cuisine',
        'Le Diffa',
        "Bro's Restaurant"
      ],
      fastFood: [
        "Frenchy's",
        'Le Berliner',
        'Osaka'
      ],
      emergencyContacts: [
        '+33 6 17 37 04 84',
        '+33 6 20 16 93 17'
      ],
      additionalInfo: {
        windows: 'Pour éviter les pigeons, ne les ouvrez pas complètement.',
        tv: 'Vérifiez que la source est sur "HDMI 1" (via la télécommande Haier).',
        heating: 'Géré à distance. Si besoin, il sera activé rapidement pour votre confort.',
        bikes: 'Aucun local dédié dans l\'immeuble.'
      }
    }
  ]);

  const [autoPilotSettings, setAutoPilotSettings] = useState<Record<string, boolean>>({
    '1': false,
    '2': false,
  });

  const handleViewConversations = (propertyId: string) => {
    navigate(`/conversations/${propertyId}`, { 
      state: { autoPilot: autoPilotSettings[propertyId] }
    });
  };

  const toggleAutoPilot = (propertyId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setAutoPilotSettings(prev => ({
      ...prev,
      [propertyId]: !prev[propertyId]
    }));
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Properties</h1>
        <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700">
          <Plus className="w-5 h-5 mr-2" />
          Add Property
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {properties.map((property) => (
          <div key={property.id} className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="relative h-48">
              <img
                src={property.photos[0]}
                alt={property.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 space-x-2">
                <button
                  onClick={() => {/* Handle edit */}}
                  className="bg-white p-2 rounded-full shadow-lg hover:bg-gray-100 transition-colors"
                >
                  <Edit2 className="w-5 h-5 text-gray-600" />
                </button>
                <button
                  onClick={() => {/* Handle delete */}}
                  className="bg-white p-2 rounded-full shadow-lg hover:bg-red-50 transition-colors"
                >
                  <Trash2 className="w-5 h-5 text-red-600" />
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{property.name}</h3>
                  <p className="text-gray-600">{property.address}</p>
                </div>
                <button
                  onClick={(e) => toggleAutoPilot(property.id, e)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors ${
                    autoPilotSettings[property.id]
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  <Zap className={`w-4 h-4 ${autoPilotSettings[property.id] ? 'text-blue-500' : 'text-gray-400'}`} />
                  <span className="text-sm font-medium">
                    {autoPilotSettings[property.id] ? 'Auto-pilot ON' : 'Auto-pilot OFF'}
                  </span>
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="flex items-center gap-2 text-gray-600">
                  <Users className="w-4 h-4" />
                  <span>Max {property.maxGuests} guests</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Clock className="w-4 h-4" />
                  <span>Check-in: {property.checkInTime}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <MessageSquare className="w-4 h-4" />
                  <span>Auto-responses</span>
                </div>
              </div>

              <button
                onClick={() => handleViewConversations(property.id)}
                className="w-full mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                View Conversations
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Properties;