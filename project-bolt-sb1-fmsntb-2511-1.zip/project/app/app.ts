import { Application } from '@nativescript/core';

Application.run({ moduleName: 'app-root' });