<content>
<script lang="ts">
  import { Frame, Page } from '@nativescript/core';
  import Home from './components/Home.svelte';
</script>

<frame>
  <Home />
</frame>
</content>